#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAX_LINE 500
#define MAX_LABEL 50
#define MAX_MEMIN_LINES 512
typedef struct {
    char name[MAX_LABEL];   // each Label has its Name and Address
    int address;

}label;

int MEM[512] = { 0 }; // the memory array
int Get_Labels(FILE* asm_file, label labels[MAX_MEMIN_LINES]);
int Assemble_Instructions(FILE* asm_file, label labels[MAX_MEMIN_LINES], FILE* MemIn);
int execute_PointWord(FILE* MemIn, int line_counter);
char* decoder(char* word[MAX_LINE]);
int If_Instruction(char line[MAX_LINE]);
int is_blank_line(char line[MAX_LINE]);

int Get_Labels(FILE* asm_file, label labels[MAX_MEMIN_LINES]) { // Scan The File and get all labels and addresses 

    char line[MAX_LINE];
    int instruction_counter = 0;
    int label_counter = 0;
    char label_index = -1;
    while (!feof(asm_file)) {
        fgets(line, MAX_LINE, asm_file);
        int cmp = is_blank_line(line);
        if (cmp == 1) { continue; } // if its a blank line continue and dont count it
        char* flag1 = strstr(line, ":"); // returns a pointer for the first appearance of ' : ' in the line
        char* flag2 = strstr(line, "#"); // returns a pointer for the first appearance of '#' in the line 
        char* flag3 = strstr(line, ".word");
        if (flag3 != NULL) // if .word is found we dont count it a an instruction and we move on
        {
            continue;
        }
        if (flag2 == NULL) // No Remark 
        {
            if (flag1 != NULL) // There is a Label 
            {
                labels[label_counter].address = instruction_counter; // add the address of the Label
                int c = 0, name_length = 0;
                while (line[c] != ':')
                {
                    if (line[c] != ' ' && line[c] != '\t')
                    {
                        labels[label_counter].name[name_length] = line[c];
                        name_length++;
                    }
                    c++;
                }
                labels[label_counter].name[name_length] = '\0';
                label_counter++;
                c = c + 1; //**
                while (c <= MAX_LINE) // Check if there is an instruction after the Label 
                {
                    if (line[c] == '\n') { break; }
                    if (line[c] != ' ' && line[c] != '\t')
                    {
                        instruction_counter++;
                        break;
                    }
                    c++;
                }
            }
            else
            {
                instruction_counter++;
                continue;
            }
        }
        else
        {
            int i = 0, done = -1;
            while (line[i] != '#') // check if The line is Just a remark 
            {
                if (line[i] != ' ' && line[i] != '\t')
                {
                    done = 1;
                    break;
                }
                i++;
            }
            if (done == 1) // The Line is not just a remark 
            {
                if (flag1 != NULL) // There is a ':' 
                {
                    if (flag1 < flag2) // the ':' comes before the '#' --> its a Label!
                    {
                        labels[label_counter].address = instruction_counter; // add the address of the Label
                        int j = 0, name_length = 0;
                        int i = 0;
                        while (line[i] != '#') //remove the remark
                        {
                            i++;
                        }
                        line[i] = '\0';
                        while (line[j] != ':')  // Add the name before the ':' to create the label name
                        {
                            if (line[j] != ' ' && line[j] != '\t')
                            {
                                labels[label_counter].name[name_length] = line[j];
                                name_length++;
                            }
                            j++;
                        }
                        j = j + 1; //**
                        labels[label_counter].name[name_length] = '\0';
                        label_counter++;
                        while (line[j]!='\0') // Check if there is an instruction after the Label 
                        {
                            if (line[j] == '\n') { break; }
                            if (line[j] != ' ' && line[j] != '\t')
                            {
                                instruction_counter++;
                                break;
                            }
                            j++;
                        }
                    }
                    else // not a Label because the ':' is part of the remark
                    {
                        instruction_counter++;
                        continue;
                    }

                }
                else
                {
                    instruction_counter++;
                    continue;
                }
            }
            else
            {
                continue;
            }



        }

    }
    fclose(asm_file);
    return 0;
}
int Assemble_Instructions(FILE* asm_file, label labels[MAX_MEMIN_LINES], FILE* MemIn)
{
    int line_counter = 0;
    char line[MAX_LINE], linetoken[MAX_LINE];
    char temp[MAX_LINE];
    char* word;
    rewind(asm_file);
    while (!feof(asm_file))
    {
        fgets(line, MAX_LINE, asm_file);
        strcpy(linetoken, line);
        int i = 0;
        int flag = If_Instruction(line);
        if (flag == 0) { continue; } // check if the line has an instruction 
        else
        {
            if (flag == 2) // Check if it is .word instruction 
            {
                if (strstr(line, "#") != NULL) //remove the remark
                {
                    int i = 0;
                    while (line[i] != '#')
                    {
                        i++;
                    }
                    line[i] = '\0';
                }
                long int address_word = -1;
                strtok(linetoken, " ");

                char* A = strtok(NULL, " ");
                if (A[0] == '0' && (A[1] == 'X' || A[1] == 'x')) // the address is in hexa
                {
                    address_word = strtol(A, NULL, 16);
                }
                else { address_word = atoi(A); } // decimal
                char* B = strtok(NULL, " \n");
                int data_word;
                if (B[0] == '0' && (B[1] == 'X' || B[1] == 'x')) // the address is in hexa
                {
                    data_word = strtol(B, NULL, 16);
                }
                else { data_word = atoi(B); } // decimal
                MEM[address_word] = data_word;
            }
            else
            {
                if (strstr(line, "#") != NULL)
                {
                    int i = 0;
                    while (line[i] != '#')
                    {
                        i++;
                    }
                    line[i] = '\0';

                }
                int i = 0, j = 0;
                strcpy(temp, line);
                if (flag == 3) // label and an instruction in the same Line so we remove the label
                {
                    while (line[j] != ':') { j++; }
                    j = j + 1;
                    while (line[j] == ' ' || line[j] == '\t') { j++; }
                    strncpy(temp, line + j, strlen(line)); // copy the instruction without the label to a new string called temp 
                }
                word = strtok(temp, ", \t");
                while (i < 4)
                {
                    char* decoded_word = decoder(word);
                    //int integer_decoded_word = atoi(decoded_word);
                    if (i == 0) { fprintf(MemIn, "%s", decoded_word); }
                    else { fprintf(MemIn, "%s", decoded_word); }
                    i++;
                    word = strtok(NULL, ", \t");
                }
                line_counter++; // counting the lines that we print 
                // now --> word = immediate 
                // we have to check if the immediate is a number or label
                if (word[0] >= 65 && word[0] <= 122) // check if its a letter --> its a Label!
                {
                    if (strstr(word, "\n") != NULL) 
                    {
                        int z = 0;
                        while (word[z] != '\n') 
                        {
                            z++;
                        }
                        word[z] = '\0';

                    }
                    int j = 0;
                    while (strcmp(labels[j].name, word) != 0) { j++; } // find the label in the labels list to know its address
                    fprintf(MemIn, "%03X\n", labels[j].address);
                }
                else // its a number 
                {
                    if (word[0] == '0' && (word[1] == 'x' || word[1] == 'X')) // its in Hexa
                    {
                        fprintf(MemIn, "%s\n", word + 2);
                    }
                    else // its decimal 
                    {
                        unsigned short U16;
                        U16 = atoi(word);
                        short U12 = U16 & 0x0FFF;
                        fprintf(MemIn, "%03X\n", U12);
                    }



                }

            }

        }

    }
    execute_PointWord(MemIn, line_counter); //execute all .word instructions
    fclose(asm_file);
    fclose(MemIn);
    return 0;
}
int is_blank_line(char line[MAX_LINE]) //check if the line is blank
{
    if (strcmp(line, "\n") == 0) { return 1; }
    int m = 0;
    for (m; m < MAX_LINE; m++)
    {
        if (line[m] != '\t' && line[m] != '\n' && line[m] != ' ') { return 0; }
        if (line[m] == '\n') { return 1; }
    }
    return 1;
}
int execute_PointWord(FILE* MemIn, int line_counter) // execute all .word instructions
{
    int i = line_counter;
    int last = 511;
    while (MEM[last] == 0)
    {
        last--;
    }
    for (i; i <= last; i++)
    {
        fprintf(MemIn, "%08X\n", MEM[i]);
    }

    return 0;
}
char* decoder(char* word[MAX_LINE]) //return the opcode of each instruction/register 
{
    if (strstr(word, "add") != NULL)
        return "00";
    if (strstr(word, "sub") != NULL)
        return "01";
    if (strstr(word, "and") != NULL)
        return "02";
    if (strstr(word, "or") != NULL)
        return "03";
    if (strstr(word, "sll") != NULL)
        return "04";
    if (strstr(word, "sra") != NULL)
        return "05";
    if (strstr(word, "srl") != NULL)
        return "06";
    if (strstr(word, "beq") != NULL)
        return "07";
    if (strstr(word, "bne") != NULL)
        return "08";
    if (strstr(word, "blt") != NULL)
        return "09";
    if (strstr(word, "bgt") != NULL)
        return "0A";
    if (strstr(word, "ble") != NULL)
        return "0B";
    if (strstr(word, "bge") != NULL)
        return "0C";
    if (strstr(word, "jal") != NULL)
        return "0D";
    if (strstr(word, "lw") != NULL)
        return "0E";
    if (strstr(word, "sw") != NULL)
        return "0F";
    if (strstr(word, "halt") != NULL)
        return "13";
    if (strstr(word, "$zero") != NULL)
        return "0";
    if (strstr(word, "$imm") != NULL)
        return "1";
    if (strstr(word, "$v0") != NULL)
        return "2";
    if (strstr(word, "$a0") != NULL)
        return "3";
    if (strstr(word, "$a1") != NULL)
        return "4";
    if (strstr(word, "$t0") != NULL)
        return "5";
    if (strstr(word, "$t1") != NULL)
        return "6";
    if (strstr(word, "$t2") != NULL)
        return "7";
    if (strstr(word, "$t3") != NULL)
        return "8";
    if (strstr(word, "$s0") != NULL)
        return "9";
    if (strstr(word, "$s1") != NULL)
        return "A";
    if (strstr(word, "$s2") != NULL)
        return "B";
    if (strstr(word, "$gp") != NULL)
        return "C";
    if (strstr(word, "$sp") != NULL)
        return "D";
    if (strstr(word, "$fp") != NULL)
        return "E";
    if (strstr(word, "$ra") != NULL)
        return "F"; 
    // here are the updates :
    if (strstr(word, "reti") != NULL)
        return "10";
    if (strstr(word, "in") != NULL)
        return "11";
    if (strstr(word, "out") != NULL)
        return "12";


    return -1;
}
int If_Instruction(char line[MAX_LINE]) // Check If Some Line is an Instruction
{
    int z = 0, m = 0;
    if (is_blank_line(line) == 1)  //blank line
    {
        return 0;
    }
    if (strstr(line, ".word") != NULL)
    {
        return 2; // .word instruction
    }
    char* flag1 = strstr(line, ":");
    char* flag2 = strstr(line, "#");
    if (flag2 != NULL)
    {
        int i = 0, done = -1;
        while (line[i] != '#') // check if The line is Just a remark 
        {
            if (line[i] != ' ' && line[i] != '\t')
            {
                done = 1;
                break;
            }
            i++;
        }
        if (done == -1)
        {
            //line is just a remark
            return 0;
        }
        else
        {
            if (flag1 == NULL)
            {
                return 1;
            }
            else
            {
                if (flag1 < flag2)
                {
                    int i = 0;
                    while (line[i] != ':')
                    {
                        i++;
                    }
                    i = i + 1;
                    while (line[i] != '#')
                    {
                        if (line[i] != ' ' && line[i] != '\t')
                        {
                            return 3; // its a label but there is an instruction in the same line
                        }
                        i++;
                    }
                    return 0; // its a label without an instruction 
                }
                return 1;
            }
        }
    }
    else
    {
        if (flag1 == NULL)
        {
            return 1;
        }
        else
        {
            int i = 0, k = 0;
            while (line[i] != ':')
            {
                i++;
            }
            for (k = i + 1; k < MAX_LINE; k++)
            {
                if (line[k] == '\n') { return 0; }
                if (line[k] != ' ' && line[k] != '\t' && line[k] != '\n')
                {
                    return 3; // its a label but there is an instruction in the same line
                }
            }
            return 0; // its a label without an instruction 

        }

    }
}
int main(int argc, char* argv[])
{
    label labels[500];
    FILE* asm_file1 = fopen(argv[1], "r");
    if (asm_file1 == NULL) //error while opening the file
    {
        exit(-1);
    }
    FILE* asm_file2 = fopen(argv[1], "r");
    if (asm_file2 == NULL)
    {
        exit(-1);
    }
    FILE* MemIn = fopen("memin.txt", "w");
    Get_Labels(asm_file2, labels);
    Assemble_Instructions(asm_file1, labels, MemIn);
    return 0;
}