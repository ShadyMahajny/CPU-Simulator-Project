
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdint.h>
#include <ctype.h>
#include <math.h>
#include <xc.h>
#include <time.h>
#include <sys/attribs.h>
#include "config.h"
#include "lcd.h"
#include "led.h"
#include "btn.h"
#include "swt.h"
#include "ssd.h"

#pragma config JTAGEN = OFF     
#pragma config FWDTEN = OFF      

// Device Config Bits in  DEVCFG1:	
#pragma config FNOSC =	PRIPLL
#pragma config FSOSCEN =	OFF
#pragma config POSCMOD =	XT
#pragma config OSCIOFNC =	ON
#pragma config FPBDIV =     DIV_2

// Device Config Bits in  DEVCFG2:	
#pragma config FPLLIDIV =	DIV_2
#pragma config FPLLMUL =	MUL_20
#pragma config FPLLODIV =	DIV_1

#define CLKS_IN_SECOND (8000000*10/2)
#define CLKS_IN_MILLISECOND (CLKS_IN_SECOND / 1000)
#define SECONDS_IN_DAY (24*3600)


// Last 32 bit clock counter sample
unsigned int clk32 = 0;
char buffer[80];
char buffer2[16];
/*
 * Last 64 bit clock counter sample
 *
 * We maintain this counter in software by polling the 32 bit hardware
 * counter frequently, detecting wrap-around, and maintaining the high
 * 32 bits in software.
 */
unsigned int clk32_prev = 0;
unsigned int clk64_msb = 0;
unsigned long long clk64;

static void clk_poll(void) {
    clk32 = _CP0_GET_COUNT();

    if (clk32 < clk32_prev) {
        clk64_msb++;
    }
    clk32_prev = clk32;
    clk64 = (((unsigned long long) clk64_msb) << 32) | clk32;
}


// define operators
#define ADD 0
#define SUB 1
#define AND 2
#define OR 3
#define SLL 4
#define SRA 5
#define SRL 6
#define BEQ 7
#define BNE 8
#define BLT 9
#define BGT 10
#define BLE 11
#define BGE 12
#define JAL 13
#define LW 14
#define SW 15
#define RETI 16
#define IN 17
#define OUT 18
#define HALT 19
#define MEMORY_SIZE 512
#define NUM_REGSTERS 16
#define LENGTH_INST 32
////////////////////
#define irq0enable 0
#define irq1enable 1
#define irq2enable 2
#define irq0status 3
#define irq1status 4
#define irq2status 5
#define irqhandler 6
#define irqreturn 7
#define clks 8 
#define reserved 9
#define display7seg 10
#define timerenable 11
#define timercurrent 12
#define timermax 13 
////////////////////
int PC = 0;
int cycles=0, counter = 0;
int irq2_cycle = 0;
int flag_irq = 0;
int countcycle = 0;
int Registers[NUM_REGSTERS] = {0};
int IORegisters[14]={0};
unsigned long Memory[MEMORY_SIZE]={0};
unsigned long memin_fib[MEMORY_SIZE]={0x00D01001, 0x04DD1007, 0x0E301020, 0x0D100006, 0x0F201021,
                0x13000000, 0x000DD1FFD, 0x0F9D1002, 0x0FFD1001, 0x0F3D1000, 0x00501001, 0x0A13500E,
                0x00230000, 0x07100018, 0x01331001, 0x0D100006, 0x00921000, 0x0E3D1000, 0x01331002,
                0x0D100006, 0x00229000, 0x0E3D1000, 0x0EFD1001, 0x0E9D1002, 0x00DD1003, 0x07F00000,
                0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x0000000B}; // 
unsigned long memin_stopper[MEMORY_SIZE]={
        0x00501001,
        0x12500000,
        0x12550000,
        0x12555000,
        0x00501006,
        0x1215000C,
        0x0050100D,
        0x121503FF,
        0x0050100B,
        0x12150001,
        0x00900000,
        0x0710000B,
        0x00501001,
        0x11610003,
        0x0716501E,
        0x11610005,
        0x0716501B,
        0x11610004,
        0x07165013,
        0x08160015,
        0x07160018,
        0x12010000,
        0x12010004,
        0x10000000,
        0x12100001,
        0x12010004,
        0x10000000,
        0x1201000A,
        0x12010005,
        0x10000000,
        0x00810009,
        0x12011001,
        0x0050100F,
        0x11B0100A,
        0x026B5000,
        0x08186032,
        0x005010F0,
        0x026B5000,
        0x00810050,
        0x08168037,
        0x00501F00,
        0x026B5000,
        0x00810900,
        0x0816803D,
        0x065B1004,
        0x00801F00,
        0x026B8000,
        0x00810500,
        0x08168043,
        0x00B00000,
        0x00BB1001,
        0x12010003,
        0x12B1000A,
        0x12111001,
        0x10000000,
        0x00BB1010,
        0x02BB1FF0,
        0x12010003,
        0x12B1000A,
        0x12111001,
        0x10000000,
        0x00BB1100,
        0x02BB1F00,
        0x12010003,
        0x12B1000A,
        0x12111001,
        0x10000000,
        0x06BB1004,
        0x00BB1100,
        0x04BB1004,
        0x02BB1000,
        0x12010003,
        0x12B1000A,
        0x12111001,
        0x10000000
    };
unsigned long instruction;
int rt, rs, rd, opcode;
int imm = 0; 
char string_PC[3];
char string_RSP[3];
char string_inst[8];
char string_seconds1[4];
char string_seconds2[4];
char string_minutes1[4];
char string_minutes2[4];
int btnu=0,btnl=0,btnr=0,btnd=0,btnc=0;
int swt0=0,swt1=0,swt2=0,swt3=0,swt4=0,swt5=0,swt6=0,swt7=0;
int flag=0, cnt=0, cnt2=1023, cnt3=0;
int pause =0;
int seconds = 0;
int one_step = 0;
int LED_on = 0;
int LED_num=0;
///////////////////////
void WriteToLCD(); //the function that writes to LCD everything as specified in the project
void UpdateTimer(); //the function updates the timercurrent register in IORegisters each 1/1024 seconds
void FillMeminArray(int swt); //fill the Memory array according to the sw7 state
void Check_Interruption(); // check if an interruption is encountered and handle it 
int ConvertNegative(unsigned long num); // convert negative Hexa to negative decimal 
void ExecuteInstruction(unsigned long inst, int imm, int rt, int rs, int rd, int opcode);
// execute the instruction according to the opcode (change the registers values)

int main(int argc, char** argv) {
    int x=0;
    SWT_Init();
    x=SWT_GetValue(7);
    FillMeminArray(x);
    WriteToLCD();
    return (1);
}

// The Operations 

void add(int rd, int rs, int rt) {
    Registers[rd] = Registers[rs] + Registers[rt];
    PC = PC + 1;
}

void reti(int rd,int rs,int rt)
{
    PC=IORegisters[7];
    flag_irq=0;
}

void in(int rd,int rs, int rt){
    Registers[rd]=IORegisters[Registers[rs]+Registers[rt]];
    PC=PC+1;
}

void out(int rd,int rs,int rt){
    IORegisters[Registers[rs]+Registers[rt]]=Registers[rd];
    PC=PC+1;
}

void sub(int rd, int rs, int rt) {
    Registers[rd] = Registers[rs] - Registers[rt];
    PC = PC + 1;
}

void and(int rd, int rs, int rt) {

    Registers[rd] = Registers[rs] & Registers[rt];
    PC = PC + 1;
}

void or(int rd, int rs, int rt) {
    Registers[rd] = Registers[rs] | Registers[rt];
    PC = PC + 1;
}

void sll(int rd, int rs, int rt) {
    Registers[rd] = Registers[rs] << Registers[rt];
    PC = PC + 1;
}

void sra(int rd, int rs, int rt) {
    Registers[rd] = Registers[rs] >> Registers[rt];
    PC = PC + 1;
}

void srl(int rd, int rs, int rt) {
    Registers[rd] = (int) ((unsigned int) Registers[rs] << Registers[rt]);
    PC = PC + 1;
}

void beq(int rd, int rs, int rt) {
    if (Registers[rs] == Registers[rt]) {
        PC = (Registers[rd]);
    } else {
        PC = PC + 1;
    }
}

void bne(int rd, int rs, int rt) {
    if (Registers[rs] != Registers[rt]) {
        PC = (Registers[rd]);
    } else {
        PC = PC + 1;
    }
}

void blt(int rd, int rs, int rt) {
    if (Registers[rs] < Registers[rt]) {
        PC = (Registers[rd]);
    } else {
        PC = PC + 1;
    }
}

void bgt(int rd, int rs, int rt) {
    if (Registers[rs] > Registers[rt]) {
        PC = (Registers[rd]);
    } else {
        PC = PC + 1;
    }
}

void ble(int rd, int rs, int rt) {
    if (Registers[rs] <= Registers[rt]) {
        PC = (Registers[rd]);
    } else {

        PC = PC + 1;
    }
}

void bge(int rd, int rs, int rt) {
    if (Registers[rs] >= Registers[rt]) {
        PC = (Registers[rd]);
    } else {
        PC = PC + 1;
    }
}

void jal(int rd, int rs, int rt) {
    Registers[15] = PC + 1;
    PC = (Registers[rd]);
}

void lw(int rd, int rs, int rt) {
    Registers[rd] = Memory[Registers[rs] + Registers[rt]];
    PC = PC + 1;
}

void sw(int rd, int rs, int rt) {
    Memory[Registers[rs] + Registers[rt]] = Registers[rd];
    PC = PC + 1;
}

void ExecuteInstruction(unsigned long inst, int imm, int rt, int rs, int rd, int opcode) {
    Registers[1] = imm;
    countcycle++; //for each instruction we do, we add 1 to countcycle 
    // Do the operation
    switch (opcode) {
        case ADD:
            add(rd, rs, rt);
            break;
        case SUB:
            sub(rd, rs, rt);
            break;
        case AND:
            and(rd, rs, rt);
            break;
        case OR:
            or(rd, rs, rt);
            break;
        case SLL:
            sll(rd, rs, rt);
            break;
        case SRA:
            sra(rd, rs, rt);
            break;
        case SRL:
            srl(rd, rs, rt);
            break;
        case BEQ:
            beq(rd, rs, rt);
            break;
        case BNE:
            bne(rd, rs, rt);
            break;
        case BLT:
            blt(rd, rs, rt);
            break;
        case BGT:
            bgt(rd, rs, rt);
            break;
        case BLE:
            ble(rd, rs, rt);
            break;
        case BGE:
            bge(rd, rs, rt);
            break;
        case JAL:
            jal(rd, rs, rt);
            break;
        case LW:
            lw(rd, rs, rt);
            break;
        case SW:
            sw(rd, rs, rt);
            break;
        case IN:
		in(rd, rs, rt);
		break;
        case OUT:
		out(rd, rs, rt);
		break;
        case RETI:
		reti(rd, rs, rt);
		break;
        case HALT:
            break;
    }
}
void FillMeminArray(int swt)
{
	int i=0;
    if(swt==0)
    {
	for(i=0;i<512;i++) {
		Memory[i] = memin_fib[i];
	}
    }
    else 
    {
        for(i=0;i<512;i++) 
        {
		Memory[i] = memin_stopper[i];
        
        }
    }
}
int ConvertNegative(unsigned long num) {
    int mask = 0x800;
    if (mask & num) { // convert to negative decimal
        num = -2 * (0x800) + (num);
    }
    return num;
}
void WriteToLCD() {
    
    LCD_Init();
    LED_Init();
    SWT_Init();
    BTN_Init();
    SSD_Init();
    int c=0, m=0x000;
    char string_m[3];
    char string_c[2];
    char string_data[8];
    char string_data_mem[8];
    char string_countcycle[8];
    SSD_Timer2Setup();
    // Do all the instructions in the memory until the halt instruction
    while(1){
        // managing the LED lightes according to the RETI operations
        if(LED_on == 1)
        {
            if(LED_num==0){
            LED_SetValue(7, 0);
            LED_SetValue(LED_num, 1);
            LED_num=(LED_num+1)%8;
            LED_on=0;}
            else
            {
             LED_SetValue(LED_num-1, 0);
            LED_SetValue(LED_num, 1);
            LED_num=(LED_num+1)%8;
            LED_on=0;
                
            }
        }
         // cnt is controlled in timer2, each 1/1024 secs cnt is bigger by 1 
        // so each 120/1024 secs we catch the switches and buttons values 
        if(cnt==120){
             cnt=0;
   SSD_WriteDigitsGrouped(IORegisters[display7seg],0); //Writing to the SSD 
   swt0=SWT_GetValue(0);
   swt1=SWT_GetValue(1);
   swt2=SWT_GetValue(2);
   swt3=SWT_GetValue(3);
   swt4=SWT_GetValue(4);
   swt5=SWT_GetValue(5);
   swt6=SWT_GetValue(6);
   swt7=SWT_GetValue(7);
   btnu=BTN_GetValue(0);
   btnc=BTN_GetValue(2);
   btnr=BTN_GetValue(3);
   btnd=BTN_GetValue(4); 
   btnl=BTN_GetValue(1);
    if (btnl)
    {
        pause=!pause;
    }
    if(btnr)
    {
     one_step = 1;  
    }
    if(btnc)
    {
        IORegisters[irq1status]=1; // handle iterruptions
    }
    if(btnd)
    {
        IORegisters[irq2status]=1;   // handle iterruptions
    }
        // option 1 - Instruction
        if((swt0==0)&&(swt1==0))
            {
             LCD_WriteStringAtPos(string_inst, 0,0);
             LCD_WriteStringAtPos("        ", 0, 8);            
            
            }
            // option 2 - Registers
        if((swt0==1)&&(swt1==0))
            {  
            sprintf(string_c, "%d", c);
            sprintf(string_data, "%08X", Registers[c]);    
             if (btnu) {
                 if(c==15){c=0;}
                 else c++;
                sprintf(string_c, "%d", c);
                sprintf(string_data, "%08X", Registers[c]);
            }
           
             LCD_WriteStringAtPos("R", 0, 0);
             if(c>=10){
             LCD_WriteStringAtPos(string_c, 0, 1);
             }
             else
             {
                 LCD_WriteStringAtPos("0", 0, 1);
                 LCD_WriteStringAtPos(string_c, 0, 2);
             }
             LCD_WriteStringAtPos(" = ", 0, 3);
             LCD_WriteStringAtPos(string_data, 0, 6);
            }
        
            // option 3 - Memory 
            if((swt0==0)&&(swt1==1))
            {  
            sprintf(string_m, "%03X", m);
            sprintf(string_data_mem, "%08X", Memory[m]);    
             if (btnu==1) {
                 if(m==0x1FF){m=0x000;}
                 else m++;
                sprintf(string_m, "%03X", m);
                sprintf(string_data_mem, "%08X", Memory[m]);
            }
             LCD_WriteStringAtPos("M", 0, 0);
             LCD_WriteStringAtPos(string_m, 0, 1);
             LCD_WriteStringAtPos(" = ", 0, 4);
             LCD_WriteStringAtPos(string_data_mem, 0, 7);
            }
            // option 4 - Number of Cycles 
            if((swt0==1)&&(swt1==1))
            {
             sprintf(string_countcycle,"%08X",countcycle);
             LCD_WriteStringAtPos(string_countcycle, 0, 0);
             LCD_WriteStringAtPos("        ", 0, 8);
            } 
            LCD_WriteStringAtPos(string_PC, 1, 0);
            LCD_WriteStringAtPos(string_RSP, 1, 4);
             
        }
        // count seconds 
        
    }
  }
void UpdateTimer() {
	if (IORegisters[timerenable] == 1) {   // timerenable=1
		if (IORegisters[timermax]) {    // timerMax>0
			if (IORegisters[timercurrent] == IORegisters[timermax]) { // timercurrent=timermax
				IORegisters[irq0status] = 1;  // irq0status=1
				IORegisters[timercurrent] = 0; // timercurrent=0
			}
			else
				IORegisters[timercurrent]++; // timercurrent++  
		}
		else {               // timerMax=0
			if (IORegisters[timercurrent] == 0xFFFFFFFF) {
				IORegisters[timercurrent] = 0;
				return;
			}
			IORegisters[timercurrent]++;     // timercurrent++
		}
	}
}
void Check_Interruption()
{
	int x_irq = 0;
    x_irq=(IORegisters[irq0enable] && IORegisters[irq0status]) || (IORegisters[irq1enable] && IORegisters[irq1status]) || (IORegisters[irq2enable] && IORegisters[irq2status]);
	if (x_irq && !flag_irq)
	{
		flag_irq = 1;
		IORegisters[irqreturn] = PC;  // irqreturn=PC
		PC = IORegisters[irqhandler];  // PC=irqhandler -- Handle the Interruption 

	}
	IORegisters[irq2status] = 0;       // irq2status=0
}
void __ISR(_TIMER_2_VECTOR, ipl7) Timer2ISR(void) 
{
cnt++;
cnt3++;
    if(cnt2==1023) // handle the time, print the num of seconds since reset
        {   
                 if (pause == 0)
                 {
                sprintf(buffer, "%08d", seconds);
                LCD_WriteStringAtPos(buffer, 1, 8);
                seconds++;
                 }
                 cnt2=0;
               
        }
cnt2++;
    if(flag==0 && pause==0){
        UpdateTimer();
        Check_Interruption();
        instruction = Memory[PC];
        imm = instruction & 0xFFF; // get the Least Significant 12 bits
        imm = ConvertNegative(imm);
        rt = (instruction >> 12) & 0xF; // we used the shifting method to split the instruction to parts 
        rs = (instruction >> 16) & 0xF;
        rd = (instruction >> 20) & 0xF;
        opcode = (instruction >> 24) & 0xFF;
         if(opcode == RETI) //used for managing the LEDs
        {
         LED_on = 1;   
        }
        ExecuteInstruction(instruction, imm, rt, rs, rd, opcode);   
        sprintf(string_PC, "%03X", PC); // Changing the values to Print
        sprintf(string_RSP, "%03X",Registers[13] );
        sprintf(string_inst, "%08X", instruction );
        if (opcode==HALT){flag=1;}
    }
    if (pause == 1 && one_step==1 ){
        UpdateTimer();
        Check_Interruption();
        instruction = Memory[PC];
        imm = instruction & 0xFFF; // get the Least Significant 12 bits
        imm = ConvertNegative(imm);
        rt = (instruction >> 12) & 0xF; // we used the shifting method to split the instruction to parts 
        rs = (instruction >> 16) & 0xF;
        rd = (instruction >> 20) & 0xF;
        opcode = (instruction >> 24) & 0xFF;
        if(opcode == RETI)
        {
         LED_on = 1;   
        }
        ExecuteInstruction(instruction, imm, rt, rs, rd, opcode);
        sprintf(string_PC, "%03X", PC);
        sprintf(string_RSP, "%03X",Registers[13] );
        sprintf(string_inst, "%08X", instruction );
        if (opcode==HALT){flag=1;}
        one_step=0;
       
    }

 
  IFS0bits.T2IF = 0;
}