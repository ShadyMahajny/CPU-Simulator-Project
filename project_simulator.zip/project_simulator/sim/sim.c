#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdint.h>
#include <ctype.h>
#include <math.h>
// define operators
#define ADD 0
#define SUB 1
#define AND 2
#define OR 3
#define SLL 4
#define SRA 5
#define SRL 6
#define BEQ 7
#define BNE 8
#define BLT 9
#define BGT 10
#define BLE 11
#define BGE 12
#define JAL 13
#define LW 14
#define SW 15
#define RETI 16
#define IN 17
#define OUT 18
#define HALT 19
#define MEMORY_SIZE 512
#define NUM_REGSTERS 16
#define LENGTH_INST 32
////////////////////////////////
// Update
#define irq0enable 0
#define irq1enable 1
#define irq2enable 2
#define irq0status 3
#define irq1status 4
#define irq2status 5
#define irqhandler 6
#define irqreturn 7
#define clks 8 
#define reserved 9
#define display7seg 10
#define timerenable 11
#define timercurrent 12
#define timermax 13 
/////////////////////////////////
int PC = 0;
int countcycle = 0;
int flag_irq = 0;
int Registers[NUM_REGSTERS] = { 0 };
unsigned long Memory[MEMORY_SIZE] = { 0 };
int IORegisters[14] = { 0 }; // un update for project 2 
////////////////////////////////
FILE* memin_file = NULL;
FILE* memout_file = NULL;
FILE* regout_file = NULL;
FILE* trace_file = NULL;
FILE* cycles_file = NULL;

FILE* OpenFile(char f_name[], char f_type[]);
void FillMeminArray(); // Scan The Memin File and save the values in the memory array
int ConvertNegative(unsigned long num); // convert negative Hexa to negative decimal 
void ExecuteInstruction(unsigned long inst, int imm, int rt, int rs, int rd, int opcode); // execute the instruction according to the opcode (change the registers values)
void WriteCycles(); // print the values in cycles file 
void WriteMemout(); // print the values in Memout file 
void WriteTrace(unsigned long inst); // print the values in Trace file
void WriteRegout(); // print the values in Regout file
void CloseFiles(); // close the files
void UpdateTimer();
void Check_Interruption();
int main()
{
	unsigned long instruction;
	int rt, rs, rd, opcode;
	int imm = 0;
	// Open files
	memin_file = OpenFile("memin.txt", "r");
	memout_file = OpenFile("memout.txt", "w");
	regout_file = OpenFile("regout.txt", "w");
	trace_file = OpenFile("trace.txt", "w");
	cycles_file = OpenFile("cycles.txt", "w");
	FillMeminArray(); // Fill the MemIn array first 
	// Do all the instructions in the memory until the halt instruction 
	while (1) {
		UpdateTimer();
		Check_Interruption();	
		instruction = Memory[PC];
		imm = instruction & 0xFFF; // get the Least Significant 12 bits
		imm = ConvertNegative(imm);
		rt = (instruction >> 12) & 0xF; // we used the shifting method to split the instruction to parts 
		rs = (instruction >> 16) & 0xF;
		rd = (instruction >> 20) & 0xF;
		opcode = (instruction >> 24) & 0xFF;
		ExecuteInstruction(instruction, imm, rt, rs, rd, opcode);
		if (opcode == HALT) break;
	}
	// Write to the files
	WriteMemout();
	WriteRegout();
	WriteCycles();
	CloseFiles();
	return 0;
}

// The updates for project 2
void reti(int rd, int rs, int rt)
{
	PC = IORegisters[7];
	flag_irq = 0;
}

void in(int rd, int rs, int rt) {
	Registers[rd] = IORegisters[Registers[rs] + Registers[rt]];
	PC = PC + 1;
}

void out(int rd, int rs, int rt) {
	IORegisters[Registers[rs] + Registers[rt]] = Registers[rd];
	PC = PC + 1;
}

// The operations /////////
void add(int rd, int rs, int rt) {
	Registers[rd] = Registers[rs] + Registers[rt];
	PC = PC + 1;
	;
}
void sub(int rd, int rs, int rt) {
	Registers[rd] = Registers[rs] - Registers[rt];
	PC = PC + 1;
}
void and (int rd, int rs, int rt) {

	Registers[rd] = Registers[rs] & Registers[rt];
	PC = PC + 1;
}
void or (int rd, int rs, int rt) {
	Registers[rd] = Registers[rs] | Registers[rt];
	PC = PC + 1;
}
void sll(int rd, int rs, int rt) {
	Registers[rd] = Registers[rs] << Registers[rt];
	PC = PC + 1;
}
void sra(int rd, int rs, int rt) {
	Registers[rd] = Registers[rs] >> Registers[rt];
	PC = PC + 1;
}
void srl(int rd, int rs, int rt) {
	Registers[rd] = (int)((unsigned int)Registers[rs] << Registers[rt]);
	PC = PC + 1;
}
void beq(int rd, int rs, int rt) {
	if (Registers[rs] == Registers[rt]) {
		PC = (Registers[rd]);
	}
	else {
		PC = PC + 1;
	}
}
void bne(int rd, int rs, int rt) {
	if (Registers[rs] != Registers[rt]) {
		PC = (Registers[rd]);
	}
	else {
		PC = PC + 1;
	}
}
void blt(int rd, int rs, int rt) {
	if (Registers[rs] < Registers[rt]) {
		PC = (Registers[rd]);
	}
	else {
		PC = PC + 1;
	}
}
void bgt(int rd, int rs, int rt) {
	if (Registers[rs] > Registers[rt]) {
		PC = (Registers[rd]);
	}
	else {
		PC = PC + 1;
	}
}
void ble(int rd, int rs, int rt) {
	if (Registers[rs] <= Registers[rt]) {
		PC = (Registers[rd]);
	}
	else {

		PC = PC + 1;
	}
}
void bge(int rd, int rs, int rt) {
	if (Registers[rs] >= Registers[rt]) {
		PC = (Registers[rd]);
	}
	else {
		PC = PC + 1;
	}
}
void jal(int rd, int rs, int rt) {
	Registers[15] = PC + 1;
	PC = (Registers[rd]);
}
void lw(int rd, int rs, int rt) {
	Registers[rd] = Memory[Registers[rs] + Registers[rt]];
	PC = PC + 1;
}
void sw(int rd, int rs, int rt) {
	Memory[Registers[rs] + Registers[rt]] = Registers[rd];
	PC = PC + 1;
}
////////////////////////////
FILE* OpenFile(char f_name[], char f_type[]) {
	FILE* Output_file = fopen(f_name, f_type);
	if (Output_file == NULL)
	{
		CloseFiles();
		exit(-1);
	}
	return Output_file;
}
void FillMeminArray() {
	char line[LENGTH_INST];
	int pc = 0;
	while (!feof(memin_file) && fgets(line, LENGTH_INST, memin_file)) {
		Memory[pc] = strtoll(line, NULL, 16) & 0xFFFFFFFF; // get each row from memin
		pc++;
	}
}
int ConvertNegative(unsigned long num) {
	int mask = 0x800;
	if (mask & num)
	{ // convert to negative decimal
		num = -2 * (0x800) + (num);
	}
	return num;
}
void ExecuteInstruction(unsigned long inst, int imm, int rt, int rs, int rd, int opcode) {
	Registers[1] = imm;
	WriteTrace(inst);
	countcycle++; //for each instruction we do, we add 1 to countcycle 
	// Do the operation
	switch (opcode) {
	case ADD:
		add(rd, rs, rt);
		break;
	case SUB:
		sub(rd, rs, rt);
		break;
	case AND:
		and (rd, rs, rt);
		break;
	case OR:
		or (rd, rs, rt);
		break;
	case SLL:
		sll(rd, rs, rt);
		break;
	case SRA:
		sra(rd, rs, rt);
		break;
	case SRL:
		srl(rd, rs, rt);
		break;
	case BEQ:
		beq(rd, rs, rt);
		break;
	case BNE:
		bne(rd, rs, rt);
		break;
	case BLT:
		blt(rd, rs, rt);
		break;
	case BGT:
		bgt(rd, rs, rt);
		break;
	case BLE:
		ble(rd, rs, rt);
		break;
	case BGE:
		bge(rd, rs, rt);
		break;
	case JAL:
		jal(rd, rs, rt);
		break;
	case LW:
		lw(rd, rs, rt);
		break;
	case SW:
		sw(rd, rs, rt);
		break;
	case IN:
		in(rd, rs, rt);
		break;
	case OUT:
		out(rd, rs, rt);
		break;
	case RETI:
		reti(rd, rs, rt);
		break;
	case HALT:
		break;
	}
}
void WriteTrace(unsigned long inst)
{
	fprintf(trace_file, "%08X %08X ", PC, inst);
	for (int i = 0; i < NUM_REGSTERS; i++)
		fprintf(trace_file, "%08X ", Registers[i]);
	fprintf(trace_file, "\n");
}
void WriteCycles() {
	fprintf(cycles_file, "%d\n", (countcycle));
}
void WriteMemout() {
	int max_address = MEMORY_SIZE - 1;
	for (; max_address >= 0; max_address--)
		if (Memory[max_address] != 0) break;
	for (int i = 0; i <= max_address; i++)
	{
		fprintf(memout_file, "%08X\n", Memory[i]);
	}
}
void WriteRegout() {
	for (int i = 2; i < NUM_REGSTERS; i++)
		fprintf(regout_file, "%08X\n", Registers[i]);
}
void CloseFiles() {
	if (memin_file != NULL) fclose(memin_file);
	if (memout_file != NULL) fclose(memout_file);
	if (regout_file != NULL) fclose(regout_file);
	if (trace_file != NULL) fclose(trace_file);
	if (cycles_file != NULL) fclose(cycles_file);
}
// New Functions
void UpdateTimer() {
	if (IORegisters[timerenable] == 1) {   // timerenable=1
		if (IORegisters[timermax]) {    // timerMax>0
			if (IORegisters[timercurrent] == IORegisters[timermax]) { // timercurrent=timermax
				IORegisters[irq0status] = 1;  // irq0status=1
				IORegisters[timercurrent] = 0; // timercurrent=0
			}
			else
				IORegisters[timercurrent]++; // timercurrent++	
		}
		else {               // timerMax=0
			if (IORegisters[timercurrent] == 0xFFFFFFFF) {
				IORegisters[timercurrent] = 0;
				return;
			}
			IORegisters[timercurrent]++;     // timercurrent++
		}
	}
}
void Check_Interruption()
{
	int x_irq = 0;
	x_irq = (IORegisters[0] && IORegisters[3]) || (IORegisters[1] && IORegisters[4]) || (IORegisters[2] && IORegisters[5]);
	if (x_irq && !flag_irq)
	{
		flag_irq = 1;
		IORegisters[7] = PC;  // irqreturn=PC
		PC = IORegisters[6];  // PC=irqhandler

	}
	IORegisters[5] = 0;       // irq2status=0
}